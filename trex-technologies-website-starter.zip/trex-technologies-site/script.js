const WHATSAPP_NUMBER = "2348130806356"; // Nigeria country code; no + or spaces.
const currency = new Intl.NumberFormat("en-NG", {style:"currency", currency:"NGN", maximumFractionDigits:0});
let products = [
  {id:1,name:"iPhone — enquire for model",category:"Phones",price:0,emoji:"📱",tag:"POPULAR",description:"Ask us about available iPhone models and storage."},
  {id:2,name:"Android smartphone",category:"Phones",price:0,emoji:"📲",tag:"SMART PICK",description:"Explore Android options to suit your needs."},
  {id:3,name:"Business laptop",category:"Laptops",price:0,emoji:"💻",tag:"WORK READY",description:"Ask about laptop specs, condition and warranty."},
  {id:4,name:"Wireless earbuds",category:"Accessories",price:25000,emoji:"🎧",tag:"ESSENTIAL",description:"A handy audio accessory for everyday listening."},
  {id:5,name:"Smart watch",category:"Accessories",price:35000,emoji:"⌚",tag:"FEATURED",description:"Keep useful everyday features close at hand."},
  {id:6,name:"Laptop accessories",category:"Accessories",price:15000,emoji:"🖱️",tag:"ADD-ON",description:"Ask about mice, chargers, keyboards and more."},
  {id:7,name:"Laptop upgrade service",category:"Laptops",price:0,emoji:"🛠️",tag:"TECH SERVICE",description:"Formatting, software installation and upgrades."},
  {id:8,name:"Phone accessories",category:"Accessories",price:10000,emoji:"🔌",tag:"EVERYDAY",description:"Ask us about cables, chargers and protection."}
];
let cart = {};
let activeCategory = "All";
let toastTimer;
const $ = s => document.querySelector(s);
const productGrid = $("#productGrid");
const formatPrice = n => n > 0 ? currency.format(n) : "Ask for price";
function showToast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2600)}
function renderProducts(){
  const q=$("#searchInput").value.trim().toLowerCase();
  const shown=products.filter(p=>(activeCategory==="All"||p.category===activeCategory)&&`${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q));
  productGrid.innerHTML=shown.length?shown.map(p=>`<article class="product-card"><div class="product-visual"><span class="product-tag">${escapeHtml(p.tag||"T-REX PICK")}</span><span class="emoji" aria-hidden="true">${p.emoji||"📦"}</span></div><div class="product-info"><div class="product-category">${escapeHtml(p.category)}</div><h3 title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</h3><p class="product-description">${escapeHtml(p.description||"Contact us for details.")}</p><div class="product-bottom"><span class="price">${formatPrice(p.price)}</span><button class="add-btn" data-add="${p.id}" aria-label="Add ${escapeHtml(p.name)} to cart">+</button></div></div></article>`).join(""):`<div class="empty-state">No products found. Try another search or category.</div>`;
  $("#adminProductsCount").textContent=products.length;
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function addToCart(id){cart[id]=(cart[id]||0)+1;renderCart();showToast("Added to your cart")}
function renderCart(){
  const entries=Object.entries(cart).map(([id,qty])=>({product:products.find(p=>p.id===Number(id)),qty})).filter(x=>x.product);
  const count=entries.reduce((n,x)=>n+x.qty,0);
  $("#cartCount").textContent=count;$("#adminCartCount").textContent=count;
  $("#cartItems").innerHTML=entries.length?entries.map(({product:p,qty})=>`<div class="cart-row"><div class="cart-emoji">${p.emoji||"📦"}</div><div class="cart-detail"><strong>${escapeHtml(p.name)}</strong><small>${formatPrice(p.price)}</small><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">+</button></div></div></div>`).join(""):`<div class="empty-state">Your cart is empty.<br><br>Explore the catalogue to add something.</div>`;
  const total=entries.reduce((n,x)=>n+(x.product.price||0)*x.qty,0);
  $("#cartTotal").textContent=currency.format(total);
}
function openOverlay(id){$("#"+id).classList.add("open");$("#"+id).setAttribute("aria-hidden","false");document.body.style.overflow="hidden"}
function closeOverlay(id){$("#"+id).classList.remove("open");$("#"+id).setAttribute("aria-hidden","true");if(!document.querySelector(".overlay.open"))document.body.style.overflow=""}
function whatsappOrder(){
  const entries=Object.entries(cart).map(([id,qty])=>({product:products.find(p=>p.id===Number(id)),qty})).filter(x=>x.product);
  if(!entries.length){showToast("Add a product to your cart first");return}
  const lines=entries.map(({product:p,qty})=>`• ${p.name} × ${qty}${p.price>0?" — "+currency.format(p.price*qty):" — price to confirm"}`);
  const total=entries.reduce((n,x)=>n+(x.product.price||0)*x.qty,0);
  const message=`Hello T-Rex Technologies! I'd like to order:\n\n${lines.join("\n")}\n\nEstimated priced items total: ${currency.format(total)}\nPlease confirm availability, final prices and delivery details.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank","noopener");
}
productGrid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)addToCart(Number(b.dataset.add))});
$("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.category===activeCategory));renderProducts()});
document.querySelectorAll(".category-card").forEach(b=>b.addEventListener("click",()=>{activeCategory=b.dataset.category==="Services"?"Laptops":b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.category===activeCategory));renderProducts();$("#shop").scrollIntoView({behavior:"smooth"})}));
$("#searchInput").addEventListener("input",renderProducts);
$("#cartBtn").addEventListener("click",()=>openOverlay("cartOverlay"));
$("#accountBtn").addEventListener("click",()=>openOverlay("accountOverlay"));
$("#adminBtn").addEventListener("click",()=>openOverlay("adminOverlay"));
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>closeOverlay(b.dataset.close)));
document.querySelectorAll(".overlay").forEach(o=>o.addEventListener("click",e=>{if(e.target===o)closeOverlay(o.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.querySelectorAll(".overlay.open").forEach(o=>closeOverlay(o.id))});
$("#cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(!b)return;const id=Number(b.dataset.qty);cart[id]=(cart[id]||0)+Number(b.dataset.delta);if(cart[id]<=0)delete cart[id];renderCart()});
$("#checkoutBtn").addEventListener("click",whatsappOrder);
$("#paymentBtn").addEventListener("click",async()=>{
  const entries=Object.entries(cart).map(([id,quantity])=>({id:String(id),quantity})).filter(x=>products.some(p=>p.id===Number(x.id)));
  if(!entries.length){showToast("Add a product to your cart first");return}
  const pricedOnly=entries.every(item=>["4","5","6","8"].includes(item.id));
  if(!pricedOnly){showToast("Some items need a confirmed price. Please use WhatsApp to order this cart.");return}
  const email=window.prompt("Enter your email address for the Paystack receipt:");
  if(email===null)return;
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){showToast("Please enter a valid email address");return}
  const button=$("#paymentBtn");button.disabled=true;button.textContent="Connecting to Paystack…";
  try{
    const response=await fetch("/api/paystack/initialize",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:email.trim(),items:entries})});
    const result=await response.json();
    if(!response.ok||!result.authorizationUrl)throw new Error(result.error||"Payment could not be started");
    window.location.href=result.authorizationUrl;
  }catch(error){showToast(error.message||"Payment setup is not ready. Try WhatsApp ordering.");}
  finally{button.disabled=false;button.textContent="Online payment with Paystack";}
});
$("#accountDemoBtn").addEventListener("click",()=>{const email=$("#accountEmail").value.trim();if(!email||!$("#accountPassword").value){$("#accountMessage").textContent="Enter an email and password to preview the next step.";return}$("#accountMessage").textContent="Demo only: no account was created and no credentials were saved. Connect secure authentication to enable sign-in."});
$("#addProductForm").addEventListener("submit",e=>{e.preventDefault();const name=$("#newProductName").value.trim(),category=$("#newProductCategory").value,price=Number($("#newProductPrice").value);if(!name||price<=0)return;products.unshift({id:Math.max(0,...products.map(p=>p.id))+1,name,category,price,emoji:category==="Phones"?"📱":category==="Laptops"?"💻":"🎧",tag:"NEW",description:"New demo item. Contact us to confirm details."});renderProducts();$("#adminMessage").textContent="Added to this browser session's demo catalogue. It will not persist to a real store database.";$("#addProductForm").reset();showToast("Demo product added")});
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
$("#mainNav").querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));
$("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();
