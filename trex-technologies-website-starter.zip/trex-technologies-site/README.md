# T-Rex Technologies — Website starter

A responsive front-end starter for **T-Rex Technologies — Home of Gadgets**.

## Included
- Mobile-friendly navy / electric-blue / cyan design
- Product catalogue with search and category filters
- Cart with quantities and estimated total
- WhatsApp order message flow for **0813 080 6356**
- Customer account preview (not real authentication)
- Admin dashboard preview with demo-only product creation
- Service and contact sections

## Run locally
Open `index.html` in a modern browser. For local development, a simple static server also works:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Before launching publicly
1. **Replace starter catalogue data** in `script.js` with real product names, current prices, descriptions, stock and product photos. Zero-price products intentionally show “Ask for price”.
2. **Register and connect your domain.** The requested `www.trextechnologies16.com` is only a proposed address until registered and DNS is configured. This starter does not publish the website or verify domain availability.
3. **Hosting:** deploy the folder to a static host such as Cloudflare Pages or Netlify, then connect your domain and enable HTTPS.
4. **Online payments:** integrate Paystack or Flutterwave using their official checkout and a secure server-side endpoint. Never put secret API keys in browser JavaScript. Verify payment server-side before confirming orders.
5. **Customer accounts:** use a trusted authentication provider and secure sessions; do not store passwords in localStorage or this front-end.
6. **Admin dashboard:** add server-side admin authentication, database-backed products/orders, role permissions, audit logging and input validation. The included dashboard is intentionally a demo and is not secure for production.
7. **Orders and inventory:** add a database/API for orders, stock reservation, order status, and admin fulfilment. The current cart is held only in browser memory.
8. **Privacy and legal:** publish a privacy notice, returns/refund policy, delivery policy, and terms appropriate to your business and payment provider.

## Main files
- `index.html` — page structure and sections
- `styles.css` — responsive visual design
- `script.js` — demo catalogue, cart and WhatsApp ordering

## Contact details configured
- Primary WhatsApp: `08130806356` (formatted for wa.me as `2348130806356`)
- Alternative phone: `08025185851`
- Email: `Derahconcepts@gmail.com`

This is a functional front-end prototype, not yet a complete production e-commerce backend. Real accounts, payments, stock sync, and admin operations require backend services.


## Paystack integration starter (Cloudflare Pages Functions)
The package now includes an initial server-side Paystack flow:
- `functions/api/paystack/initialize.js` validates the cart and calculates amounts from a server-side allowlist, then requests a Paystack checkout URL.
- `functions/api/paystack/verify.js` verifies transaction status on the server.
- `payment-callback.html` calls the verification endpoint after Paystack redirects back.
- `functions/_lib/paystack.js` contains the trusted starter price list.

### Configure safely
1. Deploy this folder to Cloudflare Pages with Functions enabled.
2. In Cloudflare Pages project settings, add `PAYSTACK_SECRET_KEY` as an encrypted secret/environment variable. Use a Paystack **test** secret first. Never put a secret key in `script.js`, HTML, GitHub, or a public file.
3. Deploy and test using the Paystack test environment before switching to live keys.
4. Ensure the server-side price allowlist in `functions/_lib/paystack.js` matches actual prices and that catalogue IDs in `script.js` remain aligned.
5. Test successful, failed, abandoned and repeated payment flows. Verify both payment status and amount on the server before fulfilling orders.

**Important limitation:** This starter verifies the payment reference but does not yet persist orders, stock, users, or admin changes in a database. Customer accounts and a secure admin dashboard still need authentication and a database (for example, Cloudflare D1 plus a properly implemented authentication layer). Do not treat this as a finished production store until those are implemented and tested.
