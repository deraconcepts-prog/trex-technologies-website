import { CATALOG, json, validEmail } from "../../_lib/paystack.js";

export async function onRequestPost({ request, env }) {
  if (!env.PAYSTACK_SECRET_KEY) return json({ error: "Payments are not configured yet." }, 503);

  let body;
  try { body = await request.json(); } catch { return json({ error: "Invalid request body." }, 400); }
  if (!validEmail(body.email)) return json({ error: "Enter a valid email address." }, 400);
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 30) {
    return json({ error: "Your cart is empty or invalid." }, 400);
  }

  // Build the order total on the server using trusted catalogue values.
  const quantities = new Map();
  for (const item of body.items) {
    const id = String(item?.id ?? "");
    const qty = Number(item?.quantity);
    if (!CATALOG[id] || !Number.isInteger(qty) || qty < 1 || qty > 10) {
      return json({ error: "One or more products cannot be paid for online. Please use WhatsApp to confirm them." }, 400);
    }
    quantities.set(id, (quantities.get(id) || 0) + qty);
    if (quantities.get(id) > 10) return json({ error: "Quantity exceeds the allowed limit." }, 400);
  }

  const items = [...quantities.entries()].map(([id, quantity]) => ({
    id, name: CATALOG[id].name, quantity, unitPriceNaira: CATALOG[id].priceNaira
  }));
  const totalNaira = items.reduce((sum, item) => sum + item.unitPriceNaira * item.quantity, 0);
  if (!Number.isSafeInteger(totalNaira) || totalNaira < 100) {
    return json({ error: "The total is invalid. Please contact us on WhatsApp." }, 400);
  }

  const reference = `trex_${crypto.randomUUID().replaceAll("-", "")}`;
  const origin = new URL(request.url).origin;
  const payload = {
    email: body.email,
    amount: String(totalNaira * 100), // Paystack expects the amount in kobo.
    currency: "NGN",
    reference,
    callback_url: `${origin}/payment-callback.html`,
    metadata: {
      custom_fields: [
        { display_name: "Store", variable_name: "store", value: "T-Rex Technologies" }
      ],
      order_items: items
    }
  };

  let response;
  try {
    response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
  } catch {
    return json({ error: "Could not contact Paystack. Please try again or order via WhatsApp." }, 502);
  }
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.status || !result.data?.authorization_url) {
    return json({ error: "Paystack could not start this payment. Please try again." }, 502);
  }
  return json({
    authorizationUrl: result.data.authorization_url,
    reference: result.data.reference,
    totalNaira
  });
}
