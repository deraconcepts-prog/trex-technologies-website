import { json } from "../../_lib/paystack.js";

export async function onRequestGet({ request, env }) {
  if (!env.PAYSTACK_SECRET_KEY) return json({ error: "Payment verification is not configured." }, 503);
  const url = new URL(request.url);
  const reference = url.searchParams.get("reference") || "";
  if (!/^[A-Za-z0-9._=-]{1,100}$/.test(reference)) return json({ error: "Invalid payment reference." }, 400);

  let response;
  try {
    response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { "Authorization": `Bearer ${env.PAYSTACK_SECRET_KEY}` }
    });
  } catch {
    return json({ error: "Unable to verify this payment right now." }, 502);
  }
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.status || !result.data) return json({ error: "Payment verification failed." }, 502);

  // Do not treat a browser redirect alone as proof of payment.
  return json({
    verified: true,
    status: result.data.status,
    reference: result.data.reference,
    amountKobo: result.data.amount,
    currency: result.data.currency
  });
}
