// Server-authoritative checkout catalogue. Prices are NGN; never trust browser-submitted prices.
export const CATALOG = {
  "4": { name: "Wireless earbuds", priceNaira: 25000 },
  "5": { name: "Smart watch", priceNaira: 35000 },
  "6": { name: "Laptop accessories", priceNaira: 15000 },
  "8": { name: "Phone accessories", priceNaira: 10000 }
};

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
}

export function validEmail(value) {
  return typeof value === "string" && value.length <= 254 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
